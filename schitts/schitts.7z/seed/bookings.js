module.exports = 
	[
		{
			id: 1,
			CustomerId: 17,
			reservation_date: "2019-02-05 14:00:00",
			party_size: 3
		},
		{
			id: 2,
			CustomerId: 45,
			reservation_date: "2019-02-05 14:30:00",
			party_size: 4
		},
		{
			id: 3,
			CustomerId: 51,
			reservation_date: "2019-02-06 20:00:00",
			party_size: 2
		},
		{
			id: 4,
			CustomerId: 89,
			reservation_date: "2019-02-06 11:00:00",
			party_size: 1
		},
		{
			id: 5,
			CustomerId: 44,
			reservation_date: "2019-02-07 13:30:00",
			party_size: 5
		},
		{
			id: 6,
			CustomerId: 39,
			reservation_date: "2019-02-08 10:00:00",
			party_size: 4
		},
		{
			id: 7,
			CustomerId: 86,
			reservation_date: "2019-02-08 15:15:00",
			party_size: 3
		},
		{
			id: 8,
			CustomerId: 17,
			reservation_date: "2019-02-09 13:00:00",
			party_size: 3
		},
		{
			id: 9,
			CustomerId: 39,
			reservation_date: "2019-02-09 10:00:00",
			party_size: 5
		},
		{
			id: 10,
			CustomerId: 33,
			reservation_date: "2019-02-09 10:00:00",
			party_size: 4
		},
		{
			id: 11,
			CustomerId: 78,
			reservation_date: "2019-02-06 14:30:00",
			party_size: 3
		},
		{
			id: 12,
			CustomerId: 84,
			reservation_date: "2019-02-06 18:00:00",
			party_size: 5
		},
		{
			id: 13,
			CustomerId: 9,
			reservation_date: "2019-02-06 15:00:00",
			party_size: 4
		}
	]
