module.exports = [{
  id: 1,
  first_name: 'john',
  last_name: 'Doe',
  email: 'johndoe@example.com',
  password: '53177XFieldstoneXPass',
  token: 'San Bernardino',
  active: true
}]
