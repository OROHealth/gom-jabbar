module.exports =
	[
		{
			id: 1,
			CustomerId: 17,
			tone: "happy",
			order_date: "2019-02-01 17:32:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		},
		{
			id: 2,
			CustomerId: 17,
			tone: "angry",
			order_date: "2019-02-02 16:52:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		},
		{
			id: 3,
			CustomerId: 2,
			tone: "pregnant",
			order_date: "2019-02-02 16:53:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		},
		{
			id: 4,
			CustomerId: 45,
			tone: "overhelmed",
			order_date: "2019-02-02 16:58:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		},
		{
			id: 5,
			CustomerId: 86,
			tone: "moody",
			order_date: "2019-02-03 12:04:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		},
		{
			id: 6,
			CustomerId: 39,
			tone: "bored",
			order_date: "2019-02-04 14:31:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		},
		{
			id: 7,
			CustomerId: 71,
			tone: "excited",
			order_date: "2019-03-15 11:31:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		},
		{
			id: 8,
			CustomerId: 17,
			tone: "happy",
			order_date: "2019-03-15 16:22:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		},
		{
			id: 9,
			CustomerId: 51,
			tone: "angry",
			order_date: "2019-03-15 18:29:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		},
		{
			id: 10,
			CustomerId: 66,
			tone: "overhelmed",
			order_date: "2019-03-15 19:25:00",
			party_size: 0,
			customers: JSON.stringify([]),
			feedback: "",
			status: "ACCEPTED",
			server: 1
		}
	]
